import {IonContent,IonPage} from '@ionic/react';


const EditUserPage = () => {
  
   
  return (
    <IonPage>
      <IonContent fullscreen>
        
      </IonContent>
    </IonPage>
  );
};

export default EditUserPage;


