import {useEffect, useState} from 'react';
import { IonContent,IonPage
} from '@ionic/react';
import { useSelector,useDispatch } from 'react-redux';
import { INCALL, useCallState } from "../../CallProvider";
import styled from "styled-components";
import { useHistory } from "react-router-dom";
import Header from '../../components/Header/Header';
import InCall from '../../components/InCall';
import {actionToGetAllUserData, actionToGetCurrentRoomData} from '../../actions/UserAction';
import {getWebsocketConnectedMessage, sendWebsocketRequest} from "../../actions/helpers/WebSocketHelper";
import {w3cwebsocket as W3CWebSocket} from "websocket";
import $ from "jquery";
let ZoomModule = null;
const UserDashboardPage = () => {
  let history = useHistory();
  const { joinRoom } = useCallState();
  const { view } = useCallState();
  const { leaveCall } = useCallState();
  const userData = useSelector((state) => state.userSignin.userInfo);
  const newJoinRoomData = useSelector((state) => state.newJoinRoomData);
  const dispatch = useDispatch();
  const [callLoading,setCallLoading] = useState(false);
    const prepareLoadingWebSDK = async (module) => {
        let ZoomMtg = module.ZoomMtg
        //await ZoomMtg.setZoomJSLib(`${window.location.origin}/node_modules/@zoomus/websdk/dist/lib`, '/av');
        await ZoomMtg.setZoomJSLib('https://source.zoom.us/2.11.0/lib', '/av');
        await ZoomMtg.preLoadWasm();
        await ZoomMtg.prepareWebSDK();

        return ZoomMtg;
    }
    const loadZoomMeeting = async () => {
        // The import method below was used because for import { ZoomMtg } from '@zoomus/websdk', the ZoomMtg CSS will overide the project's React app global CSS and will cause full black screen throughout the web app and even after if you remove the black screen, it will also cause the web page to not be scrollable or buttons/text field to not be responsive. Hence, importing the module in useEffect.
        await import("@zoomus/websdk")
            .then(async (module) => {
                try {
                    let module2 = await prepareLoadingWebSDK(module);
                    ZoomModule = module2;
                }
                catch (error) {
                    window.location.href = "/*"
                }
            })
    }

    useEffect(() => {
        loadZoomMeeting()
    }, [])



  const joinThisExsestingMeeting = (roomInfo)=>{
      if(callLoading) return;
      if(roomInfo && roomInfo != undefined){
          setCallLoading(true);
          if(ZoomModule)
             joinRoom({ userData,createMeeting:false, roomInfo,setCallLoading,ZoomMtg:ZoomModule });
      }else{
        alert('Meeting not found please ask your host to start a meeting');
      }
  }

  const userProfilePage = () =>{
    history.push('/app/user-profile');
  }
  const userSettingPage = () =>{
    history.push('/app/user-setting');
  }

   useEffect(() => {
       sendWebsocketRequest(JSON.stringify({
            clientId: localStorage.getItem('clientId'),
            data: userData,
            type: "setUserDataCurrentClient"
        }));
   }, [userData]);

   useEffect(() => {
       getWebsocketConnectedMessage(W3CWebSocket,dispatch,userData);
   }, []);

    useEffect(()=>{
        dispatch(actionToGetAllUserData(userData.created_by));
        dispatch(actionToGetCurrentRoomData());
        window.addEventListener("popstate", e => {
            leaveCall();
        });
    },[]);

    useEffect(()=>{
        const callDisconnectAlert = () =>{
            return "Leaving this page will disconnect this call?";
        }
        const callDisconnectFunction = () =>{
            leaveCall();
        }
        if (view == INCALL) {
            $(window).bind("beforeunload",callDisconnectAlert);
            $(window).bind('unload', callDisconnectFunction);
        }else{
            $(window).unbind("beforeunload",callDisconnectAlert);
            $(window).unbind('unload', callDisconnectFunction);
        }
    },[view]);

    useEffect(() => {
        const unblock = history.block(() => {
            if (view == INCALL) {
                if(window.confirm("Are you want to disconnect this call?")){
                    leaveCall();
                    return true;
                }else{
                    return false;
                }
            }
            return true;
        });
        return () => {
            unblock();
        };
    }, [history,view]);

  return (
    <IonPage>
      <Header title={userData.name} avatar={userData.avatar}/>
      <IonContent fullscreen>
          <div className="chat-list-col">
          {(view == INCALL) ?
          <InCall/>
          :
            <div className="container admin_dashboard_container">
                <div className="main-admin-screen">
                    <ul>
                        {(newJoinRoomData != null && Object.keys(newJoinRoomData).length) ?
                        <li className="main-admin-screen-item col-12">
                            <a onClick={()=>joinThisExsestingMeeting(newJoinRoomData)}>
                                <i className="fas fa-users"></i> 
                                {callLoading ? ' Joining Conference...' : ' Join Conference'}
                              
                            </a>
                        </li>
                        :''}
                        <li onClick={userProfilePage} className="main-admin-screen-item col-12">
                            <a>
                                <i className="fas fa-user"></i> Profile
                            </a>
                        </li>
                        <li onClick={userSettingPage} className="main-admin-screen-item col-12">
                            <a>
                                <i className="fas fa-cogs"></i> Change Password
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
          }
        </div>
      </IonContent>
    </IonPage>
  );
};

const NoMeetingDiv = styled.div`
width: 100%;
text-align: center;
font-size: 23px;
margin: 0px auto;
font-family: inherit;
padding-top: 30%;
`;
const MeetingRoomDiv = styled.div`
width: 100%;
text-align: center;
`;

const MeetingRoomDivSvg= styled.svg`
width: 100px;
`;

const MeetingTitleHeader= styled.div`
width: 100%;
border-bottom:1px solid #ccc;
height:50px;
`;

const MeetingFooterButton = styled.button`
    padding: 15px;
    background: #1e8d1e;
    color: #fff;
    font-size: 17px;
    border-radius: 6px;
    width: 100%;
    text-align: center;
`;
export default UserDashboardPage;


