import {
  useCallback,
  useEffect,
  useState,
  createContext,
  useContext,
} from "react";
import { useDispatch,useSelector } from 'react-redux';
import {actionToCreateRoom, actionToCreateZakToken, actionToRemoveUserFromRoom} from "./actions/UserAction";
import {sendWebsocketRequest} from "./actions/helpers/WebSocketHelper";
import { useWakeLock } from 'react-screen-wake-lock';

export const CallContext = createContext(null);

export const PREJOIN = "pre-join";
export const INCALL = "in-call";
const zoomApiKey = 'GjxRTCDmSfeUsdHoKErmqA';
const zoomApiSecret = 'qy8vtvSr6svk4Jp8PsqBK0CCEqU1jWBs';

export const CallProvider = ({ children }) => {

  const dispatch = useDispatch();
  const {userInfo} = useSelector((state) => state.userSignin);
  const [view, setView] = useState(PREJOIN); // pre-join | in-call
  const [callFrame, setCallFrame] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [room, setRoom] = useState(null);
  const [activeSpeakerId, setActiveSpeakerId] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const { isSupported, request, release } = useWakeLock({
    onRequest: () => console.log('Screen Wake Lock: requested!'),
    onError: () => console.log('An error happened!'),
    onRelease: () => console.log('Screen Wake Lock: released!'),
  });


 function joinMeeting(meetingConfig,createMeeting,userData,signature,zakToken = '',setCallLoading,setRequestToStartConCall,ZoomMtg){
        ZoomMtg.init({
            leaveUrl: window.location.origin+'/app',
            isSupportAV: false,
            success: function() {
                ZoomMtg.showJoinAudioFunction({
                    show: false
                });
                ZoomMtg.join({
                    signature: signature,
                    sdkKey: zoomApiKey,
                    meetingNumber: meetingConfig.id,
                    passWord: meetingConfig.password,
                    userName: userData?.id,
                    userEmail: userData?.email,
                    zak:zakToken,
                    success: (success) => {
                        console.log('[CALL CONNECTING SUCCESS]',success);
                        document.getElementById('zmmtg-root').style.display = 'block';
                        ZoomMtg.getCurrentUser({
                            success:function(user){
                                console.log('[CURRENT USER]',user?.result?.currentUser);
                                setCurrentUser(user.result.currentUser);
                                let buttonFound=false;
                                let t = setInterval(function(){
                                    let startButton = document.querySelector('.join-audio-by-voip__join-btn');
                                    if(startButton!=null){
                                        buttonFound = true;
                                        startButton.click();
                                    }
                                    if(buttonFound){
                                        clearInterval(t);
                                    }
                                },500);
                                //////// HERE WE ARE MUTING USER ON START CALL /////
                                if(!createMeeting){
                                    handleMute(user?.result?.currentUser?.userId);
                                }
                                //////// HERE WE ARE MUTING USER ON START CALL /////
                                if(setCallLoading){
                                    setCallLoading(false);
                                }
                                if(setRequestToStartConCall){
                                    setRequestToStartConCall(false);
                                }
                                setView(INCALL);
                            }
                        });
                    },
                    error: (error) => {
                        console.log(error)
                    }
                })
            },
            error: function(error) {
                console.error(error);
            }
        });
        setCallFrame(ZoomMtg);
    }


  const joinRoom = useCallback(
    async ({ roomInfo,userData,createMeeting,members,setCallLoading,setRequestToStartConCall,ZoomMtg}) => {
      /**
       * The first person to join will need to create the room first
       */
      if (createMeeting) {
        roomInfo = await dispatch(actionToCreateRoom(members));
        console.log('[CREATING MEETING]')
      }
      setRoom(roomInfo);


      ZoomMtg.generateSDKSignature({
            meetingNumber: roomInfo?.id,
            sdkKey: zoomApiKey,
            sdkSecret: zoomApiSecret,
            role: createMeeting ? 1 : 0,
            success: function (response) {
                if(createMeeting) {
                    dispatch(actionToCreateZakToken()).then((zakToken) => {
                        joinMeeting(roomInfo,createMeeting,userData,response.result,zakToken,setCallLoading,setRequestToStartConCall,ZoomMtg)
                    })
                }else{
                    joinMeeting(roomInfo,createMeeting,userData,response.result,'',setCallLoading,setRequestToStartConCall,ZoomMtg)
                }
           }
      })
    },[callFrame]);

  const getAccountType = useCallback((username) => {
    if (!username) return;
    // check last three letters to compare to account type constants
    return username.slice(-3);
  }, []);

  const keepAwake =  () => {
    if(isSupported){
      request();
    }
  };
  
  const allowSleep =  () => {
    if(isSupported){
      release();
    }
  };
  const leaveCall = useCallback(() => {
    setView(PREJOIN);
    if (!callFrame) return;
    async function leave() {
        callFrame.leaveMeeting({
            success: function (res) {
                console.log('[Meeting leave successfully]');
                allowSleep();
            },
            error: function (res) {
                console.log('[Error ending meeting:]', res);
            }
       });
    }
    leave();
  }, [callFrame]);

  const removeFromCall = useCallback(
    (participant) => {
      if (!callFrame) return;
      console.log("[EJECTING PARTICIPANT]", participant?.userName);
      /**
       * When the remote participant receives this message, they'll leave
       * the call on their end.
       */
       //callFrame.sendAppMessage({ msg: FORCE_EJECT }, participant?.session_id);
       dispatch(actionToRemoveUserFromRoom( participant?.userName))
    },
    [callFrame]
  );

  const endCall = useCallback(() => {
    if (!callFrame) return;
      console.log("[ENDING CALL]");
      setView(PREJOIN);
      sendWebsocketRequest(JSON.stringify({
          clientId:localStorage.getItem('clientId'),
          data:null,
          adminId:userInfo.id,
          members:[],
          type: "removeRoomToJoinSocketCall"
      }));
      callFrame.endMeeting({
          success: function () {
              allowSleep();
          },
          error: function (res) {
              console.log('[Error ending meeting:]', res);
          }
      });
  }, [participants, removeFromCall, leaveCall]);

  const displayName = useCallback((username) => {
    if (!username) return;
    // return name without account type
    return username.slice(0, username.length - 4);
  }, []);

  const handleMute = useCallback(
    (p) => {
      if (!callFrame) return;
        callFrame.mute({
            userId: p?.userId,
            mute:true,
            success: () => {
                console.log('User muted successfully.');
            },
            error: (error) => {
                console.error('Error muting user:', error);
            }
        });
        if(p?.userId !== currentUser?.userId) {
            let participantsList = [...participants];
            let found = null;
            participantsList?.map((participant, key) => {
                if (participant.userId === p.userId) {
                    found = key;
                }
            })
            if (found !== null) {
                participantsList[found] = p;
            }
            setParticipants([...participantsList]);
        }else{
            setCurrentUser(p);
        }
    },
    [callFrame]
  );
  const handleUnmute = useCallback(
    (p) => {
      if (!callFrame) return;
        if (!callFrame) return;
        callFrame.mute({
            userId: p?.userId,
            mute:false,
            success: () => {
                console.log('User muted successfully.');
            },
            error: (error) => {
                console.error('Error muting user:', error);
            }
        });
        if(p?.userId !== currentUser?.userId) {
            let participantsList = [...participants];
            let found = null;
            participantsList?.map((participant,key)=>{
                if(participant.userId === p.userId){
                    found = key;
                }
            })
            if(found !== null){
                participantsList[found] = p;
            }
            setParticipants([...participantsList]);
        }else{
            setCurrentUser(p);
        }
    },
    [callFrame]
  );

    useEffect(() => {
        if (!callFrame) return;
        callFrame.inMeetingServiceListener('onUserJoin', function (data) {
            console.log('[User join]', data);
            console.log("[UPDATING PARTICIPANT LIST]");
            let participantsList = [...participants];
            let found = null;
            participantsList?.map((participant,key)=>{
                if(participant.userId === data.userId){
                    found = key;
                }
            })
            if(found === null){
                participantsList.push(data);
            }
            setParticipants([...participantsList]);
        });
        callFrame.inMeetingServiceListener('onUserLeave', function (data) {
            console.log('[User leave]', data);
            let participantsList = [...participants];
            let found = null;
            participantsList?.map((participant,key)=>{
                if(participant.userId === data.userId){
                    found = key;
                }
            })
            if(found !== null){
                participantsList.splice(found,1);
            }
            setParticipants([...participantsList]);
        });
        callFrame.inMeetingServiceListener('onLeaveMeeting', function (data) {
            console.log('Leave meeting', data);
            leaveCall();
        });
        callFrame.inMeetingServiceListener('onUserAudioStatusChanged', (data) => {
            console.log('onUserAudioStatusChange',data)
            let participantsList = [...participants];
            let found = null;
            if(currentUser.userId !== data?.userId){
                participantsList?.map((participant,key)=>{
                    if(participant.userId === data.userId){
                        found = key;
                    }
                })
                if(found !== null){
                    participantsList.splice(found,1);
                }
                setParticipants([...participantsList]);
            }else{
                setCurrentUser(data);
            }
            if (data.action === 'joinAudio') {
                setActiveSpeakerId(data.userName);
            } else if (data.action === 'leaveAudio') {
                if(activeSpeakerId === data.userName){
                    setActiveSpeakerId({});
                }
            }
        });
        return () => {
            callFrame.inMeetingServiceListener('onUserJoin', null);
            callFrame.inMeetingServiceListener('onUserLeave', null);
            callFrame.inMeetingServiceListener('onLeaveMeeting', null);
            callFrame.inMeetingServiceListener('onUserAudioStatusChanged',null);
        }
    },[callFrame]);

  return (
    <CallContext.Provider
      value={{
        getAccountType,
        handleMute,
        handleUnmute,
        displayName,
        joinRoom,
        leaveCall,
        endCall,
        removeFromCall,
        activeSpeakerId,
        participants,
        room,
        view,
        currentUser
      }}
    >
      {children}
    </CallContext.Provider>
  );
};
export const useCallState = () => useContext(CallContext);
