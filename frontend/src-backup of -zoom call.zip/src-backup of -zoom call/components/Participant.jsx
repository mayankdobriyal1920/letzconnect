import React, { useEffect, useMemo, useRef, useState } from "react";
import styled from "styled-components";
import { useCallState } from "../CallProvider";
import { LISTENER, MOD, SPEAKER } from "../App";
import useClickAway from "../useClickAway";
import MicIcon from "./MicIcon";
import MutedIcon from "./MutedIcon";
import MoreIcon from "./MoreIcon";
import Menu from "./Menu";
import theme from "../theme";
import {useDispatch, useSelector} from 'react-redux';
import {_getImageUrlByName} from "../helpers/common";
import {actionToAddActiveSpeakingUser} from "../actions/UserAction";

const AVATAR_DIMENSION = 80;

const initials = (name) =>
  name
    ? name
        .split(" ")
        .map((n) => n.charAt(0))
        .join("")
    : "";

const Participant = ({participant}) => {
  const {
    activeSpeakerId,
  } = useCallState();

  const dispatch = useDispatch();
  const allUsersDataArray = useSelector((state) => state.allUsersDataArray);
  const {userInfo} = useSelector((state) => state.userSignin);
  const [participantUserData,setParticipantUserData] = useState(null);

  useEffect(() => {
    if(participant){
      const userId = participant?.userName;
      if(userId !== userInfo.id){
        let userData = null;
        allUsersDataArray.map((user)=>{
          if(user.id === userId){
            userData = user;
          }
        })
        setParticipantUserData(userData);
      }
    }
  }, [participant]);

  useEffect(()=>{
    if(participant?.userName === activeSpeakerId){
      dispatch(actionToAddActiveSpeakingUser(participantUserData));
    }
  },[activeSpeakerId])

  useEffect(()=>{
    return ()=>{
       if(participant?.userName == activeSpeakerId || activeSpeakerId == null || !activeSpeakerId){
         dispatch(actionToAddActiveSpeakingUser({}));
       }
    }
  },[]);

  useEffect(()=>{
    if(!participant?.audio) {
      if (participant?.userName == activeSpeakerId || activeSpeakerId == null || !activeSpeakerId) {
        dispatch(actionToAddActiveSpeakingUser({}));
      }
    }
  },[participant?.audio]);

  useEffect(()=>{
    if(!participant?.audio) {
      if (participant?.userName === activeSpeakerId || activeSpeakerId == null || !activeSpeakerId) {
        dispatch(actionToAddActiveSpeakingUser({}));
      }
    }
  },[participant]);


  return (
    <>
      {(participantUserData != null) ? 
        <Container>
            <Avatar
              muted={participant?.muted}
              isActive={activeSpeakerId === participant?.userName}>
              {(participantUserData?.avatar != null && participantUserData?.avatar) ?
                  <img alt={initials(participantUserData?.name)} className="img-fluid" src={_getImageUrlByName(participantUserData?.avatar)}/>
                  :
                  <div className={"member_name_initial"}>
                    {initials(participantUserData?.name)}
                  </div>
              }
            </Avatar>
            <Name>{participantUserData.name}</Name>
          </Container>
      :''}
    </>
  );
};

const Container = styled.div`
  display: flex;
  flex-direction: column;
  margin: 8px;
  align-items: flex-start;
  position: relative;
  max-width: 104px;
`;
const Avatar = styled.div`
  width: ${AVATAR_DIMENSION}px;
  height: ${AVATAR_DIMENSION}px;
  background-color: ${(props) => props.muted ? 'red' : theme.colors.turquoise};
  display: flex;
  border-radius:50%;
  align-items: center;
  justify-content: center;
  border: 8px solid ${(props) => (props.isActive ? '#3854bf' : "transparent")};
`;
const Name = styled.p`
  color: ${theme.colors.blueDark};
  margin: 8px 0;
  font-weight: 400;
  font-size: ${theme.fontSize.base};
  padding-left: 4px;
  max-width: 80px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 20px;
`;

export default Participant; // React.memo(Participant, (p, n) => p.participant?.id === n.participant?.id);
